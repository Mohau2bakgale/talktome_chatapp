import java.util.*;
import java.nio.file.Path;

public class QuickChat {
    private final Scanner in=new Scanner(System.in);
    private final List<Message> sent=new ArrayList<>(), discarded=new ArrayList<>();
    private final MessageArchive archive=new MessageArchive(Path.of("messages.json"));
    private final List<Message> stored=archive.load();
    private String first,last,username,password,phone;

    public static void main(String[] args){new QuickChat().run();}
    void run(){
        System.out.println("=== QuickChat Registration ===");
        first=askNonBlank("First name: "); last=askNonBlank("Surname: ");
        while(true){username=ask("Username (max 5 characters and must contain _): "); if(username.contains("_")&&username.length()<=5)break; System.out.println("Username is not correctly formatted.");}
        while(true){password=ask("Password (8+ chars, capital, number and special character): ");
            if(password.length()>=8&&password.matches(".*[A-Z].*")&&password.matches(".*[0-9].*")&&password.matches(".*[^A-Za-z0-9].*"))break;
            System.out.println("Password does not meet the requirements.");}
        while(true){phone=ask("Cellphone (+27 followed by 9 digits): "); if(phone.matches("^\\+27[6-8]\\d{8}$"))break; System.out.println("Cellphone number is incorrectly formatted.");}
        System.out.println("User has been registered successfully.");
        while(true){String u=ask("Login username: "), p=ask("Login password: ");
            if(username.equals(u)&&password.equals(p))break; System.out.println("Username or password incorrect, please try again.");}
        System.out.println("Welcome "+first+" "+last+", it is great to see you again.");
        menu();
    }
    private void menu(){
        while(true){
            System.out.println("\n=== QuickChat Menu ===\n1) Send Messages\n2) Sent Message Report\n3) Quit\n4) Stored Messages");
            int c=number("Choose: ");
            switch(c){case 1 -> sendBatch(); case 2 -> sentReport(); case 3 -> {System.out.println("Total messages sent: "+sent.size());return;} case 4 -> storedMenu(); default -> System.out.println("Please choose 1 to 4.");}
        }
    }
    private void sendBatch(){
        int count=number("How many messages would you like to enter? ");
        if(count<1){System.out.println("Enter a positive number.");return;}
        for(int i=0;i<count;i++){
            String r;
            do{r=ask("Recipient cellphone: "); if(!Message.validRecipient(r))System.out.println("Invalid recipient number.");}while(!Message.validRecipient(r));
            String t;
            do{t=ask("Message (1-250 characters): "); if(t.isBlank()||t.length()>250)System.out.println("Message must contain 1 to 250 characters.");}while(t.isBlank()||t.length()>250);
            Message m=new Message(r,t,sent.size()+stored.size()+discarded.size()+1);
            System.out.println("Message ID: "+m.getId()+"\nMessage Hash: "+m.getHash());
            int a;
            do{a=number("1) Send  2) Disregard  3) Store: ");}while(a<1||a>3);
            if(a==1){m.setStatus("Sent");sent.add(m);System.out.println("Message successfully sent.\n"+m.details());}
            else if(a==2){m.setStatus("Disregarded");discarded.add(m);System.out.println("Message disregarded.");}
            else{m.setStatus("Stored");stored.add(m);archive.save(stored);System.out.println("Message successfully stored.");}
        }
    }
    private void sentReport(){
        if(sent.isEmpty()){System.out.println("No sent messages available.");return;}
        for(Message m:sent)System.out.println(m.details()+"\n----------------");
        System.out.println("Total sent: "+sent.size());
    }
    private void storedMenu(){
        while(true){
            System.out.println("\n=== Stored Messages ===\n1) Display sender and recipient\n2) Longest stored message\n3) Search by message ID\n4) Search stored messages by recipient\n5) Delete stored message by hash\n6) Display all stored messages\n7) Search sent and stored by recipient\n8) Return to main menu");
            int c=number("Choose: ");
            switch(c){
                case 1 -> {if(stored.isEmpty())empty(); else for(Message m:stored)System.out.println("Sender: "+first+" "+last+" | Recipient: "+m.getRecipient());}
                case 2 -> {if(stored.isEmpty())empty();else {Message m=Collections.max(stored,Comparator.comparingInt(x->x.getText().length()));System.out.println("Longest stored message:\n"+m.details());}}
                case 3 -> {String id=ask("Message ID: "); Message m=findById(id); if(m==null)System.out.println("No message found.");else System.out.println(m.details());}
                case 4 -> searchRecipient(stored);
                case 5 -> {String h=ask("Message hash: "); boolean removed=stored.removeIf(m->m.getHash().equalsIgnoreCase(h)); if(removed){archive.save(stored);System.out.println("Message successfully deleted.");}else System.out.println("No stored message has that hash.");}
                case 6 -> {if(stored.isEmpty())empty();else for(Message m:stored)System.out.println(m.details()+"\n----------------");}
                case 7 -> {List<Message> all=new ArrayList<>(sent);all.addAll(stored);searchRecipient(all);}
                case 8 -> {return;}
                default -> System.out.println("Please choose 1 to 8.");
            }
        }
    }
    private Message findById(String id){for(Message m:sent)if(m.getId().equals(id))return m;for(Message m:discarded)if(m.getId().equals(id))return m;for(Message m:stored)if(m.getId().equals(id))return m;return null;}
    private void searchRecipient(List<Message> list){String r=ask("Recipient number: ");boolean found=false;for(Message m:list)if(m.getRecipient().equals(r)){System.out.println(m.details());found=true;}if(!found)System.out.println("No messages found for that recipient.");}
    private void empty(){System.out.println("No stored messages are available.");}
    private String ask(String p){System.out.print(p);return in.nextLine().trim();}
    private String askNonBlank(String p){String s;do{s=ask(p);}while(s.isBlank());return s;}
    private int number(String p){while(true){try{return Integer.parseInt(ask(p));}catch(NumberFormatException e){System.out.println("Please enter a whole number.");}}}
}
