import java.util.Locale;
import java.util.concurrent.atomic.AtomicLong;

public class Message {
    private static final AtomicLong NEXT_ID = new AtomicLong(1000000000L);
    private final String id, recipient, text, hash;
    private String status;
    public Message(String recipient, String text, int number) {
        this.id=String.format("%010d",NEXT_ID.getAndIncrement()); this.recipient=recipient; this.text=text.trim();
        String[] words=this.text.split("\\s+");
        String first=words.length==0?"":words[0].replaceAll("[^A-Za-z0-9]","");
        String last=words.length==0?"":words[words.length-1].replaceAll("[^A-Za-z0-9]","");
        this.hash=(id.substring(0,2)+":"+number+":"+first+last).toUpperCase(Locale.ROOT); this.status="Pending";
    }
    public static boolean validRecipient(String n){return n!=null&&(n.matches("^\\+27[6-8]\\d{8}$")||n.matches("^0[6-8]\\d{8}$"));}
    public boolean validText(){return !text.isBlank()&&text.length()<=250;}
    public String getId(){return id;} public String getRecipient(){return recipient;} public String getText(){return text;} public String getHash(){return hash;}
    public String getStatus(){return status;} public void setStatus(String s){status=s;}
    public String details(){return "Message ID: "+id+"\nMessage Hash: "+hash+"\nRecipient: "+recipient+"\nMessage: "+text+"\nStatus: "+status;}
    private static String esc(String s){return s.replace("\\","\\\\").replace("\"","\\\"").replace("\n","\\n").replace("\r","\\r");}
    public String json(){return "{\"id\":\""+esc(id)+"\",\"hash\":\""+esc(hash)+"\",\"recipient\":\""+esc(recipient)+"\",\"text\":\""+esc(text)+"\",\"status\":\""+esc(status)+"\"}";}
    public static Message fromJson(String line){return new Restored(field(line,"id"),field(line,"hash"),field(line,"recipient"),field(line,"text"),field(line,"status"));}
    private static String field(String s,String key){
        java.util.regex.Matcher m=java.util.regex.Pattern.compile("\""+key+"\"\\s*:\\s*\"((?:\\\\.|[^\"])*)\"").matcher(s);
        if(!m.find())return "";
        return m.group(1).replace("\\n","\n").replace("\\r","\r").replace("\\\"","\"").replace("\\\\","\\");
    }
    private static class Restored extends Message {
        private final String savedId,savedHash;
        Restored(String i,String h,String r,String t,String s){super(r,t,0);savedId=i;savedHash=h;setStatus(s);}
        @Override public String getId(){return savedId;} @Override public String getHash(){return savedHash;}
    }
}
