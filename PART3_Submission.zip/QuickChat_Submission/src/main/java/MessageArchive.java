import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

public class MessageArchive {
    private final Path path;
    public MessageArchive(Path path){this.path=path;}
    public List<Message> load() {
        List<Message> out=new ArrayList<>();
        if(!Files.exists(path)) return out;
        try {
            String content=Files.readString(path,StandardCharsets.UTF_8);
            java.util.regex.Matcher m=java.util.regex.Pattern.compile("\\{[^{}]*\\}").matcher(content);
            while(m.find()) out.add(Message.fromJson(m.group()));
        } catch(Exception e){System.out.println("Could not read message archive: "+e.getMessage());}
        return out;
    }
    public void save(List<Message> messages) {
        try {
            StringJoiner j=new StringJoiner(",\n","[\n","\n]\n");
            for(Message m:messages) j.add("  "+m.json());
            Files.writeString(path,j.toString(),StandardCharsets.UTF_8);
        } catch(IOException e){System.out.println("Could not save archive: "+e.getMessage());}
    }
}
