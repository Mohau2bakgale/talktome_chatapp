public class QuickChatSmokeTest {
    public static void main(String[] args) {
        check(Message.validRecipient("+27834557896"), "international recipient");
        check(Message.validRecipient("0838884567"), "local recipient");
        check(!Message.validRecipient("123"), "invalid recipient");
        Message m = new Message("+27834557896", "Did you get the cake?", 1);
        check(m.validText(), "valid message length");
        check(!new Message("+27834557896", "   ", 1).validText(), "blank message");
        check(m.getId().length() == 10, "ten digit ID");
        check(m.getHash().contains(":1:"), "message hash format");
        try {
            java.nio.file.Path f=java.nio.file.Files.createTempFile("quickchat", ".json");
            Message saved=new Message("+27834557896", "Persist this message", 2); saved.setStatus("Stored");
            MessageArchive archive=new MessageArchive(f); archive.save(java.util.List.of(saved));
            java.util.List<Message> loaded=archive.load();
            check(loaded.size()==1, "archive loads one message");
            check(loaded.get(0).getId().equals(saved.getId()), "archive preserves ID");
            java.nio.file.Files.deleteIfExists(f);
        } catch (Exception e) { throw new RuntimeException(e); }
        System.out.println("All 9 QuickChat smoke checks passed.");
    }
    private static void check(boolean ok, String label) {
        if (!ok) throw new AssertionError("Failed: " + label);
    }
}
