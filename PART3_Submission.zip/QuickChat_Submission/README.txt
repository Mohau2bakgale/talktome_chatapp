QUICKCHAT - PROG5121

Requirements:
- JDK 17 or later
- Apache Ant available on Windows PATH

Run:
1. Extract the complete folder.
2. Double-click QuickChat.cmd, or open CMD in this folder.
3. Run: ant clean test jar
4. Run: java -jar dist\QuickChat.jar

The app is console-based. It includes registration/login, message actions, sent report,
stored-message menu, ID and recipient searches, hash deletion, and JSON persistence.
Stored messages are saved in messages.json beside the JAR when run from this folder.

Important:
- This is a rebuilt working implementation based on the supplied demonstration guide and
  the code in your ZIP. Compare exact class names, method signatures, wording and rubric
  requirements against your official PROG5121 POE brief before submitting.
- Run it yourself and record your own demonstration in your own voice.
