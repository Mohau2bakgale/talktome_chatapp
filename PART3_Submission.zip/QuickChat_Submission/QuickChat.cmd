@echo off
title QuickChat - PROG5121
cd /d "%~dp0"
echo Checking Java...
java -version
if errorlevel 1 (
  echo Java JDK 17 or later is required.
  pause
  exit /b 1
)
where ant >nul 2>nul
if errorlevel 1 (
  echo Apache Ant is required and must be on PATH.
  pause
  exit /b 1
)
echo Building and testing QuickChat...
call ant clean test jar
if errorlevel 1 (
  echo Build or tests failed.
  pause
  exit /b 1
)
echo Starting QuickChat...
java -jar dist\QuickChat.jar
pause
