import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class LoginTest {

    @Test
    void usernameCorrectlyFormatted() {
        Login user = new Login();
        user.setUsername("kyl_1");
        assertTrue(user.checkUserName());
    }

    @Test
    void usernameIncorrectlyFormatted() {
        Login user = new Login();
        user.setUsername("kyle!!!!!!!");
        assertFalse(user.checkUserName());
    }

    @Test
    void passwordCorrectlyFormatted() {
        Login user = new Login();
        user.setPassword("Ch&8sec@ke99!");
        assertTrue(user.checkPasswordComplexity());
    }

    @Test
    void passwordIncorrectlyFormatted() {
        Login user = new Login();
        user.setPassword("password");
        assertFalse(user.checkPasswordComplexity());
    }

    @Test
    void phoneCorrectlyFormatted() {
        Login user = new Login();
        user.setCellPhoneNumber("+27838968976");
        assertTrue(user.checkCellPhoneNumber());
    }

    @Test
    void phoneIncorrectlyFormatted() {
        Login user = new Login();
        user.setCellPhoneNumber("08966553");
        assertFalse(user.checkCellPhoneNumber());
    }

    @Test
    void registrationSuccessful() {
        Login user = new Login(
                "Mohau", "Khayale", "kyl_1",
                "Ch&8sec@ke99!", "+27838968976"
        );

        assertEquals(
                "User has been registered successfully.",
                user.registerUser()
        );
    }

    @Test
    void loginSuccessful() {
        Login user = new Login(
                "Mohau", "Khayale", "kyl_1",
                "Ch&8sec@ke99!", "+27838968976"
        );

        user.setLoginDetails("kyl_1", "Ch&8sec@ke99!");

        assertTrue(user.loginUser());

        assertEquals(
                "Welcome Mohau Khayale, it is great to see you again.",
                user.returnLoginStatus()
        );
    }

    @Test
    void loginFailed() {
        Login user = new Login(
                "Mohau", "Khayale", "kyl_1",
                "Ch&8sec@ke99!", "+27838968976"
        );

        user.setLoginDetails("wrong", "wrong");

        assertFalse(user.loginUser());

        assertEquals(
                "Username or password incorrect, please try again.",
                user.returnLoginStatus()
        );
    }
}
