import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class MessageTest {

    @Test
    void messageIdIsTenCharactersOrLess() {
        Message message = new Message(
                "08575975889",
                "Mike, can you join us for dinner",
                0
        );

        assertTrue(message.checkMessageID());
        assertEquals(10, message.getMessageID().length());
    }

    @Test
    void recipientIsAccepted() {
        Message message = new Message(
                "08575975889",
                "Mike, can you join us for dinner",
                0
        );

        assertTrue(message.checkRecipientCell());
    }

    @Test
    void messageHashIsGenerated() {
        Message message = new Message(
                "08575975889",
                "Hi tonight",
                0
        );

        assertEquals(
                "00:0:HITONIGHT",
                message.getMessageHash()
        );
    }

    @Test
    void shortMessageIsAccepted() {
        Message message = new Message(
                "08575975889",
                "Hello",
                0
        );

        assertTrue(message.checkMessageLength());
    }

    @Test
    void longMessageIsRejected() {
        String longText = "a".repeat(251);

        Message message = new Message(
                "08575975889",
                longText,
                0
        );

        assertFalse(message.checkMessageLength());
    }

    @Test
    void sendChangesStatus() {
        Message message = new Message(
                "08575975889",
                "Hello",
                0
        );

        message.markSent();

        assertTrue(message.isSent());
        assertTrue(message.isReceived());
        assertFalse(message.isRead());
    }
}
