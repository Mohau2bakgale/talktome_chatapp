import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.List;

public class JsonStore {
    private final Path file;

    public JsonStore(Path file) {
        this.file = file;
    }

    public void save(Message message) throws IOException {
        String json = "{\n"
                + "  \"messageID\": \"" + escape(message.getMessageID()) + "\",\n"
                + "  \"messageHash\": \"" + escape(message.getMessageHash()) + "\",\n"
                + "  \"recipient\": \"" + escape(message.getRecipientCell()) + "\",\n"
                + "  \"message\": \"" + escape(message.getMessage()) + "\",\n"
                + "  \"sent\": " + message.isSent() + ",\n"
                + "  \"received\": " + message.isReceived() + ",\n"
                + "  \"read\": " + message.isRead() + ",\n"
                + "  \"stored\": " + message.isStored() + "\n"
                + "}\n";

        Files.writeString(file, json, StandardCharsets.UTF_8,
                StandardOpenOption.CREATE,
                StandardOpenOption.APPEND);
    }

    public String readAll() throws IOException {
        if (!Files.exists(file)) return "";
        return Files.readString(file, StandardCharsets.UTF_8);
    }

    private String escape(String value) {
        return value.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "\\r");
    }
}
