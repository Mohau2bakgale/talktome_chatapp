import javax.swing.JOptionPane;

public class Main {
    public static void main(String[] args) {

        String firstName = JOptionPane.showInputDialog(
                null, "Enter your first name:");

        if (firstName == null) return;

        String lastName = JOptionPane.showInputDialog(
                null, "Enter your last name:");

        if (lastName == null) return;

        String username = JOptionPane.showInputDialog(
                null, "Create a username:");

        if (username == null) return;

        String password = JOptionPane.showInputDialog(
                null, "Create a password:");

        if (password == null) return;

        String phone = JOptionPane.showInputDialog(
                null, "Enter your South African cell phone number "
                + "using the international code (+27):");

        if (phone == null) return;

        Login user = new Login(
                firstName,
                lastName,
                username,
                password,
                phone
        );

        String registration = user.registerUser();

        JOptionPane.showMessageDialog(
                null,
                "Username: "
                        + (user.checkUserName()
                        ? "Username successfully captured."
                        : "Username is not correctly formatted; "
                        + "please ensure that your username contains "
                        + "an underscore and is no more than five "
                        + "characters in length.")
                        + "\n\nPassword: "
                        + (user.checkPasswordComplexity()
                        ? "Password successfully captured."
                        : "Password is not correctly formatted; "
                        + "please ensure that the password contains "
                        + "at least eight characters, a capital letter, "
                        + "a number, and a special character.")
                        + "\n\nCell phone: "
                        + (user.checkCellPhoneNumber()
                        ? "Cell phone number successfully added."
                        : "Cell phone number incorrectly formatted "
                        + "or does not contain international code.")
                        + "\n\nRegistration: " + registration,
                "Registration",
                JOptionPane.INFORMATION_MESSAGE
        );

        if (!registration.equals("User has been registered successfully.")) {
            return;
        }

        String loginUsername = JOptionPane.showInputDialog(
                null, "Enter your username to log in:");

        if (loginUsername == null) return;

        String loginPassword = JOptionPane.showInputDialog(
                null, "Enter your password to log in:");

        if (loginPassword == null) return;

        user.setLoginDetails(loginUsername, loginPassword);
        user.loginUser();

        JOptionPane.showMessageDialog(
                null,
                user.returnLoginStatus(),
                "Login",
                JOptionPane.INFORMATION_MESSAGE
        );

        if (user.loginUser()) {
            ChatApp app = new ChatApp(user);
            app.start();
        }
    }
}
