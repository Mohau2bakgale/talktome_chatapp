import javax.swing.JOptionPane;
import java.io.IOException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

public class ChatApp {
    private final Login user;
    private final List<Message> messages = new ArrayList<>();
    private final List<Message> sentMessages = new ArrayList<>();
    private final List<Message> storedMessages = new ArrayList<>();
    private final JsonStore jsonStore = new JsonStore(Path.of("messages.json"));

    public ChatApp(Login user) {
        this.user = user;
    }

    public void start() {
        int messageCount = readNumberOfMessages();

        for (int i = 0; i < messageCount; i++) {
            createMessage(i);
        }

        JOptionPane.showMessageDialog(null,
                "Total messages sent: " + sentMessages.size(),
                "Chat App", JOptionPane.INFORMATION_MESSAGE);

        mainMenu();
    }

    private int readNumberOfMessages() {
        while (true) {
            String value = JOptionPane.showInputDialog(
                    null, "How many messages would you like to enter?");
            if (value == null) return 0;

            try {
                int count = Integer.parseInt(value);
                if (count >= 0) return count;
            } catch (NumberFormatException ignored) {
            }

            JOptionPane.showMessageDialog(null,
                    "Please enter a valid whole number.",
                    "Input Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void createMessage(int number) {
        String recipient;
        while (true) {
            recipient = JOptionPane.showInputDialog(
                    null, "Enter recipient cellphone number:");
            if (recipient == null) return;

            Message temporary = new Message(recipient, "temporary", number);
            if (temporary.checkRecipientCell()) break;

            JOptionPane.showMessageDialog(null,
                    "Recipient cellphone number is incorrectly formatted.",
                    "Input Error", JOptionPane.ERROR_MESSAGE);
        }

        String text;
        while (true) {
            text = JOptionPane.showInputDialog(
                    null, "Enter a message (maximum 250 characters):");
            if (text == null) return;

            Message temporary = new Message(recipient, text, number);
            if (temporary.checkMessageLength()) break;

            JOptionPane.showMessageDialog(null,
                    "Please enter a message of 250 characters or less.",
                    "Input Error", JOptionPane.ERROR_MESSAGE);
        }

        Message message = new Message(recipient, text, number);

        if (!message.checkMessageID()) {
            JOptionPane.showMessageDialog(null,
                    "Message ID is invalid.",
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        int option = JOptionPane.showOptionDialog(
                null,
                message.getFullDetails(),
                "Message",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.INFORMATION_MESSAGE,
                null,
                new String[]{"Send Message", "Disregard Message",
                             "Store Message to send later"},
                "Send Message"
        );

        if (option == 0) {
            message.markSent();
            sentMessages.add(message);
            messages.add(message);

            JOptionPane.showMessageDialog(null,
                    message.getFullDetails()
                    + "\n\nMessage successfully sent."
                    + "\nMessage status: Sent",
                    "Message Sent",
                    JOptionPane.INFORMATION_MESSAGE);

        } else if (option == 1) {
            messages.add(message);

            JOptionPane.showMessageDialog(null,
                    "Message disregarded.\nReturn value: 0",
                    "Message Disregarded",
                    JOptionPane.INFORMATION_MESSAGE);

        } else if (option == 2) {
            message.markStored();
            storedMessages.add(message);
            messages.add(message);

            try {
                jsonStore.save(message);
            } catch (IOException e) {
                JOptionPane.showMessageDialog(null,
                        "Message was stored in memory, but the JSON file "
                        + "could not be updated:\n" + e.getMessage(),
                        "File Error", JOptionPane.ERROR_MESSAGE);
            }

            JOptionPane.showMessageDialog(null,
                    "Message stored successfully.\nReturn value: 3",
                    "Message Stored",
                    JOptionPane.INFORMATION_MESSAGE);
        }
    }

    private void mainMenu() {
        while (true) {
            String[] options = {
                    "Send Messages",
                    "Show Recently Sent",
                    "Quit"
            };

            int choice = JOptionPane.showOptionDialog(
                    null,
                    "Welcome to QuickChat!\nChoose an option:",
                    "QuickChat",
                    JOptionPane.DEFAULT_OPTION,
                    JOptionPane.INFORMATION_MESSAGE,
                    null,
                    options,
                    options[0]
            );

            if (choice == 0) {
                createMessage(sentMessages.size() + storedMessages.size());

            } else if (choice == 1) {
                showRecentlySent();

            } else {
                JOptionPane.showMessageDialog(null,
                        "Thank you for using QuickChat.");
                break;
            }
        }
    }

    private void showRecentlySent() {
        if (sentMessages.isEmpty()) {
            JOptionPane.showMessageDialog(null,
                    "No recently sent messages.",
                    "Recently Sent",
                    JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        StringBuilder output = new StringBuilder();

        for (Message message : sentMessages) {
            output.append(message.getFullDetails())
                  .append("\n-----------------------------\n");
        }

        JOptionPane.showMessageDialog(null,
                output.toString(),
                "Recently Sent Messages",
                JOptionPane.INFORMATION_MESSAGE);
    }

    public List<Message> getMessages() {
        return messages;
    }

    public List<Message> getSentMessages() {
        return sentMessages;
    }

    public List<Message> getStoredMessages() {
        return storedMessages;
    }
}
