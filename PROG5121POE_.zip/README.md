# PROG5121POE - VS Code Chat App

## Requirements
- JDK 17+
- VS Code
- Extension Pack for Java
- Maven (or VS Code's Maven support)

## Project structure

```text
PROG5121POE/
├── pom.xml
├── src/
│   ├── main/java/
│   │   ├── Login.java
│   │   ├── Message.java
│   │   ├── JsonStore.java
│   │   ├── ChatApp.java
│   │   └── Main.java
│   └── test/java/
│       ├── LoginTest.java
│       └── MessageTest.java
└── .github/workflows/maven.yml
```

## Run
Open the folder in VS Code and run `Main.java`.

Or from the terminal:

```bash
mvn test
mvn package
```

The application uses JOptionPane for the chat interaction and creates `messages.json` when a message is stored for later.

## Regex reference
Oracle Java `Pattern` documentation:
https://docs.oracle.com/en/java/javase/17/docs/api/java.base/java/util/regex/Pattern.html
